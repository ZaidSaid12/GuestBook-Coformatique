/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package stockmanagementsystem;

/**
 *
 * @author Mohamed Zied
 */
public class StocksEntity 
{
    String Stock_ID;
    String Stock_name;
    String Quantity;
    String Description;
    String Category;

    public StocksEntity() 
    {
    }

   
    public StocksEntity(String Stock_ID, String Stock_name, String Quantity, String Description) {
        this.Stock_ID = Stock_ID;
        this.Stock_name = Stock_name;
        this.Quantity = Quantity;
        this.Description = Description;
        this.Category = Category;
    }


    public String getStock_ID() {
        return Stock_ID;
    }

    public void setStock_ID(String Stock_ID) {
        this.Stock_ID = Stock_ID;
    }

    public String getStock_name() {
        return Stock_name;
    }

    public void setStock_name(String Stock_name) {
        this.Stock_name = Stock_name;
    }

    public String getQuantity() {
        return Quantity;
    }

    public void setQuantity(String Quantity) {
        this.Quantity = Quantity;
    }

    public String getDescription() {
        return Description;
    }

    public void setDescription(String Description) {
        this.Description = Description;
    }

    public String getCategory() {
        return Category;
    }

    public void setCategory(String Category) {
        this.Category = Category;
    }
     @Override
    public String toString() {
        return "StockEntity" + "id=" + Stock_ID + ", name=" + Stock_name + ", Quantity=" + Quantity + ",Description"+Description+",Category"+Category+'}';
    }
}
